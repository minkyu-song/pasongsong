#include <iostream>


#define MAIN_ACTIVATION 1
#define TYPE_SELECTION 0

template<typename E, std::size_t N>
void test(E(&arr)[N]) {
	for (auto && m : arr)
	{
		std::cout << m << std::endl;
	}
}
const char m[6] = "hello";
int sum(int a, int b) { return a + b; } //sum�� ���� Ÿ���� ������


#if(TYPE_SELECTION)
template<typename R, typename...AS>
R fn_call(R(&fn)(AS...), AS... args)
{
	return fn(args...);
}
#else
// ��ó�� �ص��ǰ� �Ʒ�ó�� �ص��ǰ� �Ȱ��� �ǹ̷� ���� �ִ�.
template<typename R, typename...AS>
R fn_call(R(__cdecl &fn)(AS...), AS... args)
{
	return fn(args...);
}
#endif


struct BB {
	int sum(int a, int b, int c) { return a + b + c; }
};

template<class R, class B, class...AS>
R call_mem_fn(R(B::*fn)(AS...), B& obj, AS...args)
{
	return (obj.*fn)(args...);//�����Ͱ� �ƴѰ��
}

#if(MAIN_ACTIVATION)
int main()
{
	test(m);
	std::cout << fn_call(sum, 10, 40) << std::endl;
	std::cout << typeid(&BB::sum).name() << std::endl;
	BB bb;
	std::cout << call_mem_fn(&BB::sum, bb, 100, 200, 300) << std::endl;

}
#endif